'use strict';

function isoDate(value) {
  return typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value) ? value : '';
}

function addDays(iso, days) {
  const [y, m, d] = iso.split('-').map(Number);
  const date = new Date(Date.UTC(y, m - 1, d));
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}

function buildFinanceInsights({ today, cash = 0, projects = [], expenses = [] }) {
  if (!isoDate(today)) throw new Error('Дата должна быть в формате YYYY-MM-DD.');
  const activeProjects = projects.filter(p => p.status !== 'cancelled');
  const receivables = activeProjects.map(p => {
    const received = Math.max(0, Number(p.received_rub || 0));
    const contract = Math.max(0, Number(p.contract_rub || 0));
    return { ...p, debtRub: Math.max(0, contract - received) };
  }).filter(p => p.debtRub > 0);
  const unpaid = expenses.filter(e => Number(e.is_paid) === 0).map(e => ({
    ...e, amountRub: Math.max(0, Number(e.amount_rub || 0)), dueDate: isoDate(e.expense_date)
  }));
  const forecasts = [7, 30].map(days => {
    const through = addDays(today, days);
    const expectedReceipts = receivables.filter(p => isoDate(p.end_date) && isoDate(p.end_date) >= today && isoDate(p.end_date) <= through)
      .reduce((sum, p) => sum + p.debtRub, 0);
    const plannedOutflow = unpaid.filter(e => e.dueDate && e.dueDate <= through)
      .reduce((sum, e) => sum + e.amountRub, 0);
    return { days, through, expectedReceipts, plannedOutflow, projectedCash: Number(cash || 0) + expectedReceipts - plannedOutflow };
  });
  const risks = activeProjects.map(p => {
    const contract = Math.max(0, Number(p.contract_rub || 0));
    const paid = Math.max(0, Number(p.paid_expenses_rub || 0));
    const planned = Math.max(0, Number(p.planned_expenses_rub || 0));
    const total = paid + planned;
    const ratio = contract > 0 ? total / contract : null;
    return { id: p.id, title: p.title, contractRub: contract, paidExpensesRub: paid, plannedExpensesRub: planned,
      costRatio: ratio, level: ratio === null ? 'unknown' : ratio >= 1 ? 'over' : ratio >= 0.8 ? 'warning' : 'ok' };
  }).filter(p => p.level === 'warning' || p.level === 'over').sort((a,b) => (b.costRatio || 0) - (a.costRatio || 0));
  const overdueExpenses = unpaid.filter(e => e.dueDate && e.dueDate < today);
  const unscheduledReceivables = receivables.filter(p => !isoDate(p.end_date));
  return {
    today, cash: Number(cash || 0), forecasts, risks,
    receivablesTotal: receivables.reduce((sum, p) => sum + p.debtRub, 0),
    unscheduledReceivablesTotal: unscheduledReceivables.reduce((sum, p) => sum + p.debtRub, 0),
    unscheduledReceivables, unpaidTotal: unpaid.reduce((sum, e) => sum + e.amountRub, 0),
    overdueExpensesTotal: overdueExpenses.reduce((sum, e) => sum + e.amountRub, 0),
    overdueExpensesCount: overdueExpenses.length
  };
}

module.exports = { buildFinanceInsights, addDays };
